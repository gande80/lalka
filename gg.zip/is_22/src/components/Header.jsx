import React from 'react'
import Logo from "./../assets/Logo.svg"

const HeaderComponent = () => {
    return (
        <div>
            <div className='flex justify-center'>
                <img src={Logo} alt="Logo" className="max-w-12.2 max-h-3.8 mt-1.625 mr-10 ml-3 mt-2 " />
                    <div className='flex gap-3 justify-center mt-3'>
                        <a href="#">услуги</a>
                        <a href="#">о нас</a>
                        <a href="#">польза продукта</a>
                        <a href="#">оборудование</a>
                        <a href="#">этапы работы</a>
                        <a href="#">отзывы</a>
                </div>
                <div className='bg-[#5CCD6A] py-1 px-3 rounded-2xl shadow-lg border-white ml-8 mt-1 mr-3 '>
                    <button>
                        СВЯЗАТСЯ
                    </button>
                </div>
            </div>
        </div>
    )
}

export default HeaderComponent
