import { useState } from 'react'
import HeaderComponent from './components/Header'

function App() {

  return (
    <>
      <div>
        <HeaderComponent />
      </div>
    </>
  )
}

export default App
